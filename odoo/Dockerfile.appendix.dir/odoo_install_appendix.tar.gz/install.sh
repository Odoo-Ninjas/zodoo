#!/bin/bash
set -x

# ODBC
# connstr = f"Driver={{IBM i Access ODBC Driver 64-bit}};DSN=epg;UID={USER};PWD={PWD}"
apt update && \
apt install -y \
unixodbc-dev \
odbc-postgresql

dpkg -i ibm-iaccess-1.1.0.27-1.0.amd64.deb
cp odbc.ini /etc/odbc.ini